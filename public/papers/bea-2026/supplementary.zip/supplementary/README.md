# Supplementary Materials

## Tables
- `evidence_table.xlsx` — Per-paragraph evidence table: 213 Rozental paragraphs x 3 corpora (GERA, RULEC, LORuGEC), with verified error examples
- `cross_reference.xlsx` — Cross-reference: 98 fine-grained tags mapped to corpus tagsets (RULEC, GERA, LORuGEC, RLC) with L2 applicability ratings
- `per_rule_lorugec.csv` — Per-rule exact-match accuracy: 48 LORuGEC rules x 35 model conditions

## Reasoning traces
- `qwen35_9b_think_lorugec_test.jsonl` — Qwen3.5-9B thinking mode, 612 LORuGEC test examples with full reasoning chains
- `qwen35_35b_think_lorugec_test.jsonl` — Qwen3.5-35B-A3B thinking mode, 612 LORuGEC test examples with full reasoning chains

## classified_gera.jsonl

Full GERA reclassification distribution (5,988 records). Each line is one error reclassified from GERA's POS-based tag into the Rozental taxonomy, with the LLM's reasoning, confidence, and the candidate set considered. Referenced in Table gera-reclass.
