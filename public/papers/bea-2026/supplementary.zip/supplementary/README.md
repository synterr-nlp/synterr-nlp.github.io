# Supplementary Materials

## Tables
- `evidence_table.xlsx` — Per-paragraph evidence table: 213 Rozental paragraphs x 3 corpora (GERA, RULEC, LORuGEC), with verified error examples
- `cross_reference.xlsx` — Cross-reference: 98 fine-grained tags mapped to corpus tagsets (RULEC, GERA, LORuGEC, RLC) with L2 applicability ratings
- `per_rule_lorugec.csv` — Per-rule exact-match accuracy: 48 LORuGEC rules x 35 model conditions

## Reasoning traces
- `qwen35_9b_think_lorugec_test.jsonl` — Qwen3.5-9B thinking mode, 612 LORuGEC test examples with full reasoning chains
- `qwen35_35b_think_lorugec_test.jsonl` — Qwen3.5-35B-A3B thinking mode, 612 LORuGEC test examples with full reasoning chains

## classified_gera.jsonl

Full GERA reclassification distribution (5,988 records). Each line is one error reclassified from GERA's POS-based tag into the Rozental taxonomy, with the LLM's reasoning, confidence, and the candidate set considered. Referenced in Table gera-reclass.

## Training data and reproducibility

The actual v4 SFT training data (39,209 examples, ~21 MB) lives in the
synterr repo: data/qwen_sft_v4.jsonl. This bundle ships the small
reproducibility files needed to verify it:

- V4_DATA_PROVENANCE.md — full pipeline description, pinned generation commit
- v4_checksums.txt — SHA-256 of every v4 artifact, byte-verified against frodo
- verify_v4.py — runs the checksums against your local copies
- qwen_sft_v4.dist.json — per-rule generation distribution sidecar
- mixed_sources_v4.meta.json — source-mix build metadata

To verify locally:

    git clone https://github.com/synterr-nlp/synterr
    cd synterr
    uv run python scripts/verify_v4.py
